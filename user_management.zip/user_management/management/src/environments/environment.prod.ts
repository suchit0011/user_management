export const environment = {
  production: true,
  api_endpoint:'http://localhost:3000/api/user/'
};
